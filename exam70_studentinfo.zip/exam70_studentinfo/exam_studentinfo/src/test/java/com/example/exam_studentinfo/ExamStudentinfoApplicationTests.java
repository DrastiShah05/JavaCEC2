package com.example.exam_studentinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamStudentinfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
