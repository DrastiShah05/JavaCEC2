package com.example.exam_studentinfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamStudentinfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamStudentinfoApplication.class, args);
	}

}
